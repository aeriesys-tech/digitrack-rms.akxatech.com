<?php

namespace Webklex\PHPIMAP\Events;


class MessageRestoredEvent extends MessageNewEvent {

}
