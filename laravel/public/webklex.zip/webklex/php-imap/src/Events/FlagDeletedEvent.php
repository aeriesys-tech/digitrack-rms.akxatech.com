<?php

namespace Webklex\PHPIMAP\Events;


class FlagDeletedEvent extends FlagNewEvent {

}
