<?php

namespace Webklex\PHPIMAP\Events;


class MessageDeletedEvent extends MessageNewEvent {

}
