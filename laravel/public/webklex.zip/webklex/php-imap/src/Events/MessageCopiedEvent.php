<?php

namespace Webklex\PHPIMAP\Events;


class MessageCopiedEvent extends MessageMovedEvent {

}
