<?php

namespace Webklex\PHPIMAP\Events;

class FolderDeletedEvent extends FolderNewEvent {

}
