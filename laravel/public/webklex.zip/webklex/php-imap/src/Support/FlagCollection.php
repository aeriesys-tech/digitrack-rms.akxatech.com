<?php
/*
* File:     FlagCollection.php
* Category: Collection
* Author:   M. Goldenbaum
* Created:  21.07.18 23:10
* Updated:  -
*
* Description:
*  -
*/

namespace Webklex\PHPIMAP\Support;

/**
 * Class FlagCollection
 *
 * @package Webklex\PHPIMAP\Support
 */
class FlagCollection extends PaginatedCollection {

}