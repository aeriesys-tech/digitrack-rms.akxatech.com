---
name: General help request
about: Feel free to ask about any project related stuff

---

Please be aware that these issues will be closed if inactive for more then 14 days :)
